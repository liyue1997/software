const config = {
  SERVER_ADDR = '/common',
};

export default config;